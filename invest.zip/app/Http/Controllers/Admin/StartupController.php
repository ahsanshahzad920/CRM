<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Startup;
use Illuminate\Http\Request;

class StartupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $startup = Startup::orderBy('id','ASC')->get();
        return view('admin/startup.index',compact('startup'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin/startup/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validation = $request->validate(
            [
                'name' => 'required|max:255',
                'type1' => 'required|max:255',
                'amount1' => 'required|max:255',
                'type2' => 'required|max:255',
                'amount2' => 'required|max:255',
                'image' => 'required|max:10248|mimes:jpeg,png,jpg',
                'description' => 'required'
            ]
        );
        $startup = new Startup;
        if ($request->hasfile('image')) {
            $image = $request->file('image');
            $upload = 'Images/';
            $filename = time() . $image->getClientOriginalName();
            $path    = move_uploaded_file($image->getPathName(), $upload . $filename);
            $startup->image = $upload . $filename;
        }
        $startup->name = $request->name;
        $startup->type1 = $request->type1;
        $startup->amount1 = $request->amount1;
        $startup->type2 = $request->type2;
        $startup->amount2 = $request->amount2;
        $startup->description = $request->description;
        $startup->save();
        return redirect('admin/startup')->with('success','Startup has created!');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Startup  $startup
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $startup = Startup::find($id);
        return view('admin/startup.show',compact('startup'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Startup  $startup
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $startup = Startup::find($id);
        return view('admin/startup.edit',compact('startup'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Startup  $startup
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $validation = $request->validate(
            [
                'name' => 'required|max:255',
                'type1' => 'required|max:255',
                'amount1' => 'required|max:255',
                'type2' => 'required|max:255',
                'amount2' => 'required|max:255',
                'description' => 'required'
            ]
        );
        
        $startup = Startup::find($id);
        if ($request->hasfile('image')) {
            $image = $request->file('image');
            $upload = 'Images/';
            $filename = time() . $image->getClientOriginalName();
            $path    = move_uploaded_file($image->getPathName(), $upload . $filename);
            $startup->image = $upload . $filename;
        }
        $startup->name = $request->name;
        $startup->type1 = $request->type1;
        $startup->amount1 = $request->amount1;
        $startup->type2 = $request->type2;
        $startup->amount2 = $request->amount2;
        $startup->description = $request->description;
        $startup->update();
        return redirect('admin/startup')->with('success','Startup has updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Startup  $startup
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $startup = Startup::find($request->id);
        $startup->delete();
        return response(['message' => 'Startup delete successfully']);
    }
}
