<?php

namespace App\Http\Controllers\Admin;

use App\HowWork;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HowWorkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $HowWork = HowWork::orderBy('id','ASC')->get();
        return view('admin/HowWork.index',compact('HowWork'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin/HowWork/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validation = $request->validate(
            [
                'name' => 'required|max:255',
                'image' => 'required|max:10248|mimes:jpeg,png,jpg',
                'description' => 'required'
            ]
        );
        $HowWork = new HowWork;
        if ($request->hasfile('image')) {
            $image = $request->file('image');
            $upload = 'Images/';
            $filename = time() . $image->getClientOriginalName();
            $path    = move_uploaded_file($image->getPathName(), $upload . $filename);
            $HowWork->icon = $upload . $filename;
        }
        $HowWork->name = $request->name;
        $HowWork->description = $request->description;
        $HowWork->save();
        return redirect('admin/HowWork')->with('success','How Work has created!');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\HowWork  $HowWork
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $HowWork = HowWork::find($id);
        return view('admin/HowWork.show',compact('HowWork'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\HowWork  $HowWork
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $HowWork = HowWork::find($id);
        return view('admin/HowWork.edit',compact('HowWork'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\HowWork  $HowWork
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $validation = $request->validate(
            [
                'name' => 'required|max:255',
                'description' => 'required'
            ]
        );
        $HowWork = HowWork::find($id);
        if ($request->hasfile('image')) {
            $image = $request->file('image');
            $upload = 'Images/';
            $filename = time() . $image->getClientOriginalName();
            $path    = move_uploaded_file($image->getPathName(), $upload . $filename);
            $HowWork->icon = $upload . $filename;
        }
        $HowWork->name = $request->name;
        $HowWork->description = $request->description;
        $HowWork->update();
        return redirect('admin/HowWork')->with('success','How Work has updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\HowWork  $HowWork
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $HowWork = HowWork::find($request->id);
        $HowWork->delete();
        return response(['message' => 'HowWork delete successfully']);
    }
}
