<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Startup extends Model
{
    //
}
