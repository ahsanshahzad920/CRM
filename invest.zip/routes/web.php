<?php

use Illuminate\Support\Facades\Route;
// Route::get('/', function () {
//     return view('welcome');
// });
// profile
Route::group(['middleware' => ['auth']], function () {
    Route::get('profile', 'ProfileController@index');
    Route::post('update-profile', 'ProfileController@update');
});

// User
Route::group(['as' => 'client.', 'middleware' => ['auth']], function () {
    Route::get('home', 'HomeController@redirect');

    
});

Route::get('/', 'HomeController@home')->name('/');


Auth::routes();



// Admin

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'namespace' => 'Admin', 'middleware' => ['auth.admin']], function () {

    Route::get('/admin', 'HomeController@index')->name('home');
    Route::get('paid-users/{id?}', 'HomeController@paidUsers');
    


   
    // Permissions
    Route::delete('permissions/destroy', 'PermissionsController@massDestroy')->name('permissions.massDestroy');
    Route::resource('permissions', 'PermissionsController');

    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');

    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::resource('users', 'UsersController');

    // startup
    Route::resource('startup', 'StartupController');
    Route::post('deletestartup', 'StartupController@destroy')->name('deleteStartup');
    // Review
    Route::resource('review', 'ReviewController');
    Route::post('deletereview', 'ReviewController@destroy')->name('deleteReview');
    // How Work
    Route::resource('HowWork', 'HowWorkController');
    Route::post('deleteHowWork', 'HowWorkController@destroy')->name('deleteHowWork');
    // Faq
    Route::resource('faq', 'FaqController');
    Route::post('deleteFaq', 'FaqController@destroy')->name('deleteFaq');
    // Company
    Route::resource('company', 'CompanyController');
    Route::post('deleteCompany', 'CompanyController@destroy')->name('deleteCompany');
    // Service
    Route::resource('service', 'ServiceController');
    Route::post('deleteService', 'ServiceController@destroy')->name('deleteService');

    // Website Content
    Route::resource('content', 'ContentController');
    
});


Route::group(['middleware' => ['auth']], function () {

    Route::get('stripe', 'StripeController@stripe');
    Route::post('stripe', 'StripeController@stripePost')->name('stripe.post');
});

