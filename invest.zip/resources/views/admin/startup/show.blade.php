@extends('layouts.admin')
@section('content')

    <div class="card">
        <div class="card-header">
            Show Startup
        </div>

        <div class="card-body">
            <div class="form-group">
                <div class="form-group">
                    <a class="btn btn-default" href="{{ route('admin.startup.index') }}">
                        Back
                    </a>
                </div>
                <table class="table table-bordered table-striped">
                    <tbody>
                        <tr>
                            <th>
                                ID
                            </th>
                            <td>
                                {{ $startup->id }}
                            </td>
                        </tr>
                        <tr>
                            <th>
                                Name
                            </th>
                            <td>
                                {{ $startup->name }}
                            </td>
                        </tr>
                        <tr>
                            <th>
                                Type
                            </th>
                            <td>
                                {{ $startup->type1 }}
                            </td>
                        </tr>
                        <tr>
                            <th>
                                Amount
                            </th>
                            <td>
                                {{ $startup->amount1 }}
                            </td>
                        </tr>
                        <tr>
                            <th>
                                Type
                            </th>
                            <td>
                                {{ $startup->type2 }}
                            </td>
                        </tr>
                        <tr>
                            <th>
                                Amount
                            </th>
                            <td>
                                {{ $startup->amount2 }}
                            </td>
                        </tr>
                        <tr>
                            <th>
                                Image
                            </th>
                            <td>
                                <img src="{{asset($startup->image)}}" style="width:200px; height:200px;" alt="">
                            </td>
                        </tr>
                        <tr>
                            <th>
                                Description
                            </th>
                            <td>
                                {{$startup->description}}
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="form-group">
                    <a class="btn btn-default" href="{{ route('admin.startup.index') }}">
                        Back
                    </a>
                </div>
            </div>
        </div>
    </div>



@endsection
