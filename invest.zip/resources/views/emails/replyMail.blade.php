<!DOCTYPE html>
<html>
<head>
    <title>Legacy Writer</title>
</head>
<body>
    <b>Hi,</b><br>
    <p>{{ $details['body'] }}</p>
   
</body>
</html>