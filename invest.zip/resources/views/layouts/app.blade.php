<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('assets-web/css/bootstrap.min.css') }}">
    <!-- slider cdn -->
    <link rel="stylesheet" href="{{ asset('assets-web/css/flickity.min.css') }}">
    <title></title>
    <link rel="stylesheet" href="{{ asset('assets-web/css/style.css') }}">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	@yield('style')
</head>

<body>
    <header>
        <div class="container-fluid">
            <nav class="navbar navigation-wrap  navbar-expand-lg ">
                <a class="navbar-brand text-primary" href="#">Logo</a>
                <button class="navbar-toggler collapsed d-flex d-lg-none flex-column justify-content-around"
                    type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="toggler-icon top-bar"></span>
                    <span class="toggler-icon middle-bar"></span>
                    <span class="toggler-icon bottom-bar"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarNav">
                    <ul class="navbar-nav ml-auto my-2 my-lg-0 navbar-nav-scroll">
                        <li class="nav-item active">
                            <a class="nav-link " href="#">Invest </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Raise</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Resources</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Company</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Browse startups</a>
                        </li>
                    </ul>
                    <div class="nav_btn navbar-nav ml-md-5 d-flex justify-content-center flex-row align-items-center">
                        <a href="{{url('login')}}" class="btn btn-outline-primary mr-2">Login</a>
                        <a href="{{url('register')}}" class=" btn btn-primary">Sign up</a>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <div class="home-warper">
		@yield('content')
        <footer>
            <div class="footer">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-md-12 col-lg-3 mt-3 text-center text-lg-left">
                            <div>
                                <a href="#" class="logo2 ">Logo</a>
                                <div class="social_icon mt-4">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                    <a href=""><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 col-lg-3 mt-3   text-md-left">
                            <div class="footer_link">
                                <ul>
                                    <li><a href="">Home</a></li>
                                    <li><a href="">Who we are</a></li>
                                    <li><a href="">Start Investing</a></li>
                                    <li><a href="">Sign up</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 col-lg-3 mt-3 text-md-left">
                            <div class="footer_link">
                                <ul>
                                    <li><a href="">Privacy Policy</a></li>
                                    <li><a href="">Term of use</a></li>
                                    <li><a href="">Legal</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-12 p-0 col-md-4 col-lg-3 mt-3 text-center text-md-left">
                            <div class="footer_link">
                                <ul>
                                    <li><a href="">90 Paul Street, Landon ,EC2A </a></li>
                                    <li><a href="">+263 77 149 0081</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div
                        class=" mt-3 d-md-flex d-block justify-content-md-between align-items-center text-white disclamer">
                        <div class="disclaimer_border">
                            <p>Disclaimer</p>
                        </div>
                        <div>
                            <p class="ml-md-3"><span>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam
                                    nonumy eirmod
                                    tempor
                                    invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. t vero eos et
                                    accusam et
                                    justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus
                                    est Lorem ipsum
                                    dolor sit amet.
                                </span></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer2 text-center text-white py-4 m-auto">
                <p class="mb-0">© Copyright Company Name 2021</p>
            </div>
        </footer>
    </div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="{{ asset('assets-web/js/jquery-3.6.0.js') }}"></script>
    <script src="{{ asset('assets-web/js/popper.min.js') }}"></script>
    <script src="{{ asset('assets-web/js//bootstrap.min.js') }}"></script>
    <script src="{{ asset('assets-web/js/1103de08f5.js') }}" crossorigin="anonymous"></script>
    <!-- slider cdn  -->
    <script src="{{ asset('assets-web/js/flickity.pkgd.min.js') }}"></script>
    <script src="{{ asset('assets-web/js/script.js') }}"></script>
	@yield('script')
</body>

</html>
