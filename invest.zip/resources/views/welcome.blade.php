@php
    $data = content();
@endphp
@extends('layouts.app')
@section('content')
    <section class="banner header-top ">
        <div class="container-fluid">
            <div class="row mx-0 align-items-center">
                <div class="col-12 col-md-5">
                    <div class="content">
                        <h1>{!!$data['#banner']['heading']??''!!}</h1>
                        <p>{!!$data['#banner']['description']??''!!}</p>
                        <button class="btn btn-primary py-2 mt-4">Start Investing</button>
                    </div>
                </div>
                <div class="col-12 col-md-7">
                    <img src="{{ asset($data['#banner']['image']) }}" class="img-fluid w-100">
                </div>
            </div>
        </div>
    </section>
    <section class="explore-investments">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-8 mx-auto">
                    <h1>Explore Investments</h1>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
                        labore
                        et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et ju</p>
                </div>
            </div>
            <div class="row">
              @foreach ($startup as $item)
                <div class="col-12 col-md-4">
                    <div class="box">
                        <img src="{{ asset($item->image??'') }}" class="img-fluid w-100">
                        <div class="px-2 pb-3">
                            <h5>{{$item->name??''}}</h5>
                            <h6>{{$item->description??''}}</h6>
                            <div class="row mt-2">
                                <div class="col-6 border-right">
                                    <p class="text-primary mb-0">${{$item->amount1??''}}</p>
                                    <small>{{$item->type1??''}}</small>
                                </div>
                                <div class="col-6 ">
                                    <p class="text-primary mb-0">${{$item->amount2??''}}</p>
                                    <small>{{$item->type2??''}}</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="text-center mt-5">
                <button class="btn btn-primary py-2">View All Startups</button>
            </div>
        </div>
    </section>
    <section class="how-works">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-8 mx-auto">
                    <h1>How It Works</h1>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
                        labore
                        et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et ju</p>
                </div>
            </div>
            <div class="row">
              @foreach ($howWork as $item)
                <div class="col-12 col-md-4 mt-3">
                    <div class="card">
                        <img src="{{ asset($item->icon??'') }}">
                        <h5>{{$item->name??''}}</h5>
                        <p>{{$item->description??''}}</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
    <section class="invester-feedback">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-8 mx-auto">
                    <h1>Join 697,000+ Investors</h1>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
                        labore
                        et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et ju</p>
                </div>
            </div>
            <div class="testimonal mt-5">
                <div class="carousel" data-flickity='{ "wrapAround": true ,"autoPlay": 1500  }'>
                  @foreach ($review as $item)
                    <div class="carousel-cell border shadow">
                        <div class="container ">
                            <div class="row">
                                <div class="col-12 col-lg-6 col-md-6 ">
                                    <img src="{{ asset($item->image??'') }}" alt="">
                                </div>
                                <div class="col-12 col-lg-6 col-md-6  text-lg-left text-md-left text-center">
                                    <h3>{{$item->name??''}}</h3>
                                    <div class="my-2">
                                        <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i
                                            class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i
                                            class="fa-solid fa-star mr-2"></i>{{$item->rate??''}}
                                    </div>
                                    <p class="text-lg-left text-md-left">{{$item->description??''}}</p>
                                    <p class="minutes mt-5 text-lg-left text-md-left">2 minutes ago</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>


    <section class="how-works raise-company">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-5">
                    <h1>Looking To Raise A Round <h1>
                            <h1>For Your Company?</h1>
                </div>
            </div>
            <div class="row mt-4">
              @foreach ($service as $item)
                <div class="col-12 col-md-4  mt-3 ">
                    <div class="card">
                        <img src="{{ asset($item->icon??'') }}">
                        <h5>{{$item->name??''}}</h5>
                        <p>{{$item->description??''}}</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
    <section class="raised_aroung ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-8 mx-auto text-center mb-4 heading_s">
                    <h1>See Who Else Raised A Round</h1>
                    <p>Portfolio company highlights</p>
                </div>
            </div>
            <div class="row">
              @foreach ($company as $item)
                <div class="col-6 p-1 col-lg-3 col-md-4">
                    <div class="raised_logo ">
                        <img src="{{ asset($item->logo??'') }}" alt="">
                        <h4>{{$item->name??''}}</h4>
                        <h5>${{$item->amount??''}}</h5>
                        <br>
                        <p>{{$item->description??''}}</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
    <section class="faqs my-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-8 mx-auto text-center my-4 heading_s">
                    <h1>Still Have Questions?</h1>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
                        labore
                        et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et ju</p>
                </div>
            </div>
            <div class="container">
                <ul class="acc">
                  @foreach ($faq as $item)
                    <li>
                        <button class="acc_ctrl">
                            <h2>{{$item->name??''}}</h2>
                        </button>
                        <div class="acc_panel">
                            <p>{{$item->description}}</p>
                        </div>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </section>
@endsection
