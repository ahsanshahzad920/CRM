@extends('layouts.app')

@section('content')
<div class="signup">
	<div class="container ">
		<div class="row ">
			<div class="col-10 col-md-8  mx-auto">
				<div class="form_heading text-center">
					<h1>Create Account</h1>
					<p>Start building your diversified, vetted startup portfolio today.</p>
				</div>
			</div>
		</div>
		<div class="row ">
			<div class="col-10 col-md-8 col-lg-5  mx-auto">
				<div class="signform">
					<form action="{{ route('register') }}" method="POST">
						@csrf
						@if ($errors->any())
							<div class="alert alert-danger">
								<ul>
									@foreach ($errors->all() as $error)
										<li>{{ $error }}</li>
									@endforeach
								</ul>
							</div>
						@endif
						<div class="form-group">
							<label for="firstName">First Name</label>
							<input type="text" class="form-control form-control-lg" id="firstName"
								aria-describedby="fnameHelp" placeholder="First Name" name="first_name" value="{{ old('first_name') }}">
						</div>
						<div class="form-group">
							<label for="lastName">Last Name</label>
							<input type="text" class="form-control form-control-lg" id="lastName"
								aria-describedby="lnameHelp" placeholder="Last Name" name="last_name" value="{{ old('last_name') }}">
						</div>
						<div class="form-group">
							<label for="emailAddress">Email Address</label>
							<input type="email" class="form-control form-control-lg" id="emailAddress"
								aria-describedby="emailHelp" placeholder="Email" name="email" value="{{ old('email') }}">
						</div>
						<div class="form-group">
							<label for="pword">Password</label>
							<input type="password" class="form-control form-control-lg" id="pword" placeholder="*******" name="password">
						  </div>
						<div class="form-group">
							<label for="investor">I'm a</label>
							<select class="form-control form-control-lg" id="investor">
								<option>Accredited Investor</option>
								<option>2</option>
								<option>3</option>
								<option>4</option>
								<option>5</option>
							</select>
						</div>
						<div class="text-center">
							<button type="submit" class="form-control formbtn">Sign Up </button>
						</div>
						<p class="text-right mt-4"><a href="{{ route('password.request') }}">Forgot Password</a></p>
					</form>
					<div class="Signup_with my-3">
						<p class="my-4 text-center">OR</p>
						<div class=" text-center signup_icons mt-5">
							<a href="#"><img src="{{asset('assets-web/img/Mask Group 6.png')}}" alt=""></a>
							<a href="#"><img
									src="{{asset('assets-web/img/google-logo-icon-png-transparent-background-osteopathy-16.png')}}"
									alt=""></a>
							<a href="#"><img src="{{asset('assets-web/img/Facebook-logo.png')}}" alt=""></a>
						</div>
						<div class="freesign text-center my-4">
							<p> Do you have an account?<a href="{{url('login')}}"> Login</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection