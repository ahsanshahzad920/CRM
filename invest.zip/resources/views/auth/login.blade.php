@extends('layouts.app')

@section('content')
    <div class="signup">
        <div class="container ">
            <div class="row ">
                <div class="col-10 col-md-8  mx-auto">
                    <div class="form_heading text-center">
                        <h1>Login</h1>
                        <p>Start building your diversified, vetted startup portfolio today.</p>
                    </div>
                </div>
            </div>
            <div class="row ">
                <div class="col-10 col-md-8 col-lg-5  mx-auto">
                    <div class="signform">
                        <form action="{{ route('login') }}" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="emailAddress">Email address</label>
                                <input type="email" class="form-control form-control-lg" id="emailAddress"
                                    aria-describedby="emailHelp" name="email" value="{{ old('email') }}"
                                    placeholder="Email here">
                            </div>
                            <div class="form-group">
                                <label for="pword">Password</label>
                                <input type="password" class="form-control form-control-lg" id="pword" name="password"
                                    placeholder="*******">
                            </div>
                            <div class="text-center">
                                <button type="submit" class="formbtn form-control">Login</button>
                            </div>
                            <p class="text-right mt-4"><a href="{{ route('password.request') }}">Forgot Password</a></p>
                        </form>
                        <div class="Signup_with my-3">
                            <p class="my-4 text-center">OR</p>
                            <div class=" text-center signup_icons mt-5">
                                <a href="#"><img src="{{ asset('assets/img/Mask Group 6.png') }}" alt=""></a>
                                <a href="#"><img
                                        src="{{ asset('assets/img/google-logo-icon-png-transparent-background-osteopathy-16.png') }}"
                                        alt=""></a>
                                <a href="#"><img src="{{ asset('assets/img/Facebook-logo.png') }}" alt=""></a>
                            </div>
                            <div class="freesign text-center my-4">
                                <p> Don't have an account?<a href="{{ url('register') }}"> Sign up for free here</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
