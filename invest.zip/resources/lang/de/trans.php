<?php

return [
    'test'   => 'ich teste'
];
