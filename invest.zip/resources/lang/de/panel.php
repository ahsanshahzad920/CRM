<?php

return [
    'site_title' => 'Test',
];
